const getAllVacantesPyR = require('./getAllVacantesPyR.js');
const getVacanteAsignadaPyR = require('./getVacanteAsignadaPyR.js');

module.exports={
    getAllVacantesPyR,
    getVacanteAsignadaPyR
}
