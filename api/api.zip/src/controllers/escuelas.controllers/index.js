const getAllEscuelas = require('./getAllEscuelas.js');

module.exports={
    getAllEscuelas,
};