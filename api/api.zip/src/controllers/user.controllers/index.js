const validateUser = require('./validateuser');
const changePass = require('./changePass');

module.exports={
    validateUser,
    changePass
}